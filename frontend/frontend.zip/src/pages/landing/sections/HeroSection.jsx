import { ArrowRight, Sparkles } from 'lucide-react';

function scrollTo(href) {
  document.querySelector(href)?.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

export default function HeroSection() {
  return (
    <section className="hz-hero">
      <div className="container position-relative" style={{ padding: '96px 0 88px', zIndex: 1 }}>
        <div className="row align-items-center g-5">
          <div className="col-12 col-lg-6">
            <span className="hz-hero-eyebrow">
              <Sparkles size={13} /> Enterprise HRMS platform
            </span>

            <h1 className="mt-4 mb-3" style={{ fontSize: 'clamp(2.25rem, 4vw, 3.25rem)', fontWeight: 700, lineHeight: 1.12 }}>
              One platform for your entire workforce.
            </h1>

            <p style={{ fontSize: 'var(--hz-text-lg)', color: 'rgba(255,255,255,0.82)', maxWidth: 520, marginBottom: 36 }}>
              Attendance, leave, performance, and people operations - built for organizations that have outgrown
              spreadsheets and outgrown generic HR software too.
            </p>

            <div className="d-flex flex-wrap gap-3">
              <button className="hz-btn-hero-primary d-inline-flex align-items-center gap-2" onClick={() => scrollTo('#contact')}>
                Request Demo <ArrowRight size={16} />
              </button>
              <button className="hz-btn-hero-secondary" onClick={() => scrollTo('#careers')}>
                View Careers
              </button>
            </div>

            <div className="d-flex align-items-center gap-4 mt-5 flex-wrap" style={{ opacity: 0.7 }}>
              <MiniStat label="Modules" value="6+" />
              <MiniStat label="Role-based access" value="Built-in" />
              <MiniStat label="Deployment" value="Cloud or on-prem" />
            </div>
          </div>

          <div className="col-12 col-lg-6">
            <div className="hz-hero-art">
              <div className="hz-hero-art-panel">
                <DashboardGlyph />
              </div>

              <div className="hz-hero-chip" style={{ top: -18, left: -6, animationDelay: '0s' }}>
                <span className="hz-chip-dot" style={{ background: 'var(--hz-success-500)' }} />
                Leave request approved
              </div>
              <div className="hz-hero-chip" style={{ bottom: 26, right: -18, animationDelay: '1.2s' }}>
                <span className="hz-chip-dot" style={{ background: 'var(--hz-accent-500)' }} />
                Attendance synced live
              </div>
              <div className="hz-hero-chip" style={{ bottom: -20, left: 40, animationDelay: '0.6s' }}>
                <span className="hz-chip-dot" style={{ background: 'var(--hz-primary-500)' }} />
                Performance review · Q3
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function MiniStat({ label, value }) {
  return (
    <div>
      <div style={{ fontSize: 'var(--hz-text-sm)', fontWeight: 700, color: '#fff' }}>{value}</div>
      <div style={{ fontSize: 11, textTransform: 'uppercase', letterSpacing: '0.06em', color: 'rgba(255,255,255,0.6)' }}>{label}</div>
    </div>
  );
}

/** Abstract "product" glyph - a dashboard made of bars, a trend line, and a
 *  ring - built in plain SVG so the hero never depends on a fabricated
 *  screenshot of a screen that doesn't exist yet. */
function DashboardGlyph() {
  return (
    <svg viewBox="0 0 420 300" width="100%" height="auto" role="img" aria-label="Illustration of workforce analytics dashboard">
      <rect x="0" y="0" width="420" height="300" rx="14" fill="rgba(255,255,255,0.04)" />

      {/* bar chart */}
      {[
        { x: 24, h: 70 },
        { x: 62, h: 110 },
        { x: 100, h: 88 },
        { x: 138, h: 140 },
        { x: 176, h: 100 },
      ].map((bar, i) => (
        <rect
          key={i}
          x={bar.x}
          y={220 - bar.h}
          width="26"
          height={bar.h}
          rx="6"
          fill={i === 3 ? '#0ea5a4' : 'rgba(255,255,255,0.55)'}
        />
      ))}
      <line x1="10" y1="220" x2="220" y2="220" stroke="rgba(255,255,255,0.25)" strokeWidth="1.5" />

      {/* trend line */}
      <polyline
        points="248,150 278,120 308,135 338,88 368,102 396,64"
        fill="none"
        stroke="#a5b4fc"
        strokeWidth="3"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      {[
        [248, 150],
        [278, 120],
        [308, 135],
        [338, 88],
        [368, 102],
        [396, 64],
      ].map(([cx, cy], i) => (
        <circle key={i} cx={cx} cy={cy} r="4" fill="#fff" />
      ))}

      {/* progress ring */}
      <circle cx="330" cy="220" r="34" stroke="rgba(255,255,255,0.18)" strokeWidth="10" fill="none" />
      <circle
        cx="330"
        cy="220"
        r="34"
        stroke="#0ea5a4"
        strokeWidth="10"
        fill="none"
        strokeDasharray={2 * Math.PI * 34}
        strokeDashoffset={2 * Math.PI * 34 * 0.28}
        strokeLinecap="round"
        transform="rotate(-90 330 220)"
      />
    </svg>
  );
}
