import { useMemo, useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { FileSpreadsheet, FileText, TrendingUp, TrendingDown, Clock3, Trophy, ListFilter } from 'lucide-react';
import { monitoringReportsApi, formatHoursMinutes } from '../../api/endpoints/monitoring';
import { departmentsApi } from '../../api/endpoints/organization';
import { employeesApi } from '../../api/endpoints/employees';
import { formatDateTimeIST, toISTDateInputValue } from '../../utils/formatDateTime';
import Card from '../../components/ui/Card';
import Badge from '../../components/ui/Badge';
import Table from '../../components/ui/Table';
import Button from '../../components/ui/Button';
import FormField from '../../components/ui/FormField';
import { SkeletonCard } from '../../components/ui/Skeleton';
import { useToast } from '../../components/ui/Toast';

function defaultRange() {
  const end = toISTDateInputValue(new Date());
  const start = toISTDateInputValue(new Date(Date.now() - 6 * 24 * 60 * 60 * 1000)); // last 7 days
  return { startDate: start, endDate: end };
}

/**
 * Requirements #3/#4 (Activity Reports + Productivity Summary), #5/#6
 * (Excel/PDF Export), #7 (Report Filters) and #8 (Management View), all in
 * one page - every number comes from MonitoringReportController, which
 * derives everything from real activity_session rows, never mock data.
 */
export default function ProductivityReports() {
  const [filters, setFilters] = useState(() => ({
    ...defaultRange(),
    employeeId: '',
    employeeName: '',
    departmentId: '',
    deviceName: '',
  }));
  const [exporting, setExporting] = useState(null);
  const toast = useToast();

  const { data: employees } = useQuery({ queryKey: ['employees-directory'], queryFn: () => employeesApi.list() });
  const { data: departments } = useQuery({ queryKey: ['departments-directory'], queryFn: departmentsApi.list });

  const {
    data: rows,
    isLoading: rowsLoading,
    isError: rowsError,
    refetch: refetchRows,
  } = useQuery({
    queryKey: ['monitoring-productivity', filters],
    queryFn: () => monitoringReportsApi.productivity(filters),
  });

  const { data: insights, isLoading: insightsLoading } = useQuery({
    queryKey: ['monitoring-management', filters],
    queryFn: () => monitoringReportsApi.management(filters),
  });

  const set = (key) => (value) => setFilters((f) => ({ ...f, [key]: value }));

  async function handleExport(kind) {
    setExporting(kind);
    try {
      if (kind === 'excel') {
        await monitoringReportsApi.exportExcel(filters);
      } else {
        await monitoringReportsApi.exportPdf(filters);
      }
      toast.success(`${kind === 'excel' ? 'Excel' : 'PDF'} report downloaded`);
    } catch (err) {
      toast.error(err.response?.data?.message || `Could not export ${kind.toUpperCase()}`);
    } finally {
      setExporting(null);
    }
  }

  const columns = useMemo(
    () => [
      { key: 'employeeId', label: 'Employee ID', headerClassName: 'ps-4', className: 'ps-4', render: (r) => r.employeeCode || '—' },
      { key: 'employeeName', label: 'Employee Name', render: (r) => r.employeeName || '—' },
      { key: 'device', label: 'Device Name', render: (r) => r.deviceName || '—' },
      { key: 'department', label: 'Department', render: (r) => r.departmentName || '—' },
      { key: 'date', label: 'Date', render: (r) => (r.date ? formatDateTimeIST(`${r.date}T00:00:00`).split(',')[0] : '—') },
      { key: 'loggedIn', label: 'Logged In', render: (r) => formatHoursMinutes(r.totalLoggedInSeconds) },
      { key: 'active', label: 'Active', render: (r) => formatHoursMinutes(r.activeSeconds) },
      { key: 'idle', label: 'Idle', render: (r) => formatHoursMinutes(r.idleSeconds) },
      { key: 'break', label: 'Break', render: (r) => formatHoursMinutes(r.breakSeconds) },
      {
        key: 'productivity',
        label: 'Productivity',
        headerClassName: 'pe-4',
        className: 'pe-4',
        render: (r) => (
          <Badge variant={r.productivityPercent >= 70 ? 'success' : r.productivityPercent >= 40 ? 'warning' : 'danger'}>
            {r.productivityPercent?.toFixed(1)}%
          </Badge>
        ),
      },
    ],
    []
  );

  return (
    <div className="d-flex flex-column gap-4">
      <div className="d-flex align-items-start justify-content-between flex-wrap gap-2">
        <div>
          <h1 style={{ fontSize: 'var(--hz-text-2xl)', fontWeight: 700 }}>Productivity Reports</h1>
          <p className="text-secondary-hz" style={{ fontSize: 'var(--hz-text-sm)' }}>
            Activity reports, productivity summary, and management insights from live agent data
          </p>
        </div>
        <div className="d-flex gap-2">
          <Button variant="secondary" icon={FileSpreadsheet} loading={exporting === 'excel'} onClick={() => handleExport('excel')}>
            Export Excel
          </Button>
          <Button variant="secondary" icon={FileText} loading={exporting === 'pdf'} onClick={() => handleExport('pdf')}>
            Export PDF
          </Button>
        </div>
      </div>

      {/* Requirement #7 - Report Filters */}
      <Card title="Filters" actions={<ListFilter size={16} style={{ color: 'var(--hz-text-muted)' }} />}>
        <div className="row">
          <FormField type="date" col={2} label="Start Date" value={filters.startDate} onChange={set('startDate')} />
          <FormField type="date" col={2} label="End Date" value={filters.endDate} onChange={set('endDate')} />
          <FormField as="select" col={3} label="Employee" value={filters.employeeId} onChange={set('employeeId')}>
            <option value="">All Employees</option>
            {(employees || []).map((e) => (
              <option key={e.id} value={e.id}>
                {e.fullName} ({e.employeeCode})
              </option>
            ))}
          </FormField>
          <FormField as="select" col={3} label="Department" value={filters.departmentId} onChange={set('departmentId')}>
            <option value="">All Departments</option>
            {(departments || []).map((d) => (
              <option key={d.id} value={d.id}>
                {d.name}
              </option>
            ))}
          </FormField>
          <FormField col={2} label="Device Name" value={filters.deviceName} onChange={set('deviceName')} placeholder="Search device" />
        </div>
      </Card>

      {/* Requirement #8 - Management View */}
      <div className="row g-3">
        {insightsLoading ? (
          Array.from({ length: 4 }).map((_, i) => (
            <div className="col-12 col-md-6 col-xl-3" key={i}>
              <SkeletonCard />
            </div>
          ))
        ) : (
          <>
            <div className="col-12 col-xl-6">
              <Card title="Most Active Employees" actions={<TrendingUp size={16} style={{ color: 'var(--hz-success-500)' }} />}>
                <RankingList
                  items={insights?.mostActiveEmployees}
                  unit="h active"
                  emptyText="No activity in this period"
                />
              </Card>
            </div>
            <div className="col-12 col-xl-6">
              <Card title="Highest Idle Employees" actions={<TrendingDown size={16} style={{ color: 'var(--hz-danger-500)' }} />}>
                <RankingList items={insights?.highestIdleEmployees} unit="h idle/break" emptyText="No idle time recorded" />
              </Card>
            </div>
            <div className="col-12 col-xl-6">
              <Card title="Productivity Ranking" actions={<Trophy size={16} style={{ color: 'var(--hz-warning-500)' }} />}>
                <RankingList items={insights?.productivityRanking} unit="% avg" emptyText="No data for ranking" />
              </Card>
            </div>
            <div className="col-12 col-xl-6">
              <Card title="Averages" actions={<Clock3 size={16} style={{ color: 'var(--hz-text-muted)' }} />}>
                <div className="d-flex flex-column gap-3 py-2">
                  <div className="d-flex justify-content-between align-items-center">
                    <span className="text-secondary-hz" style={{ fontSize: 'var(--hz-text-sm)' }}>
                      Average Working Hours / Day
                    </span>
                    <span style={{ fontWeight: 700, fontSize: 'var(--hz-text-lg)' }}>
                      {(insights?.averageWorkingHours ?? 0).toFixed(1)}h
                    </span>
                  </div>
                  <div className="d-flex justify-content-between align-items-center">
                    <span className="text-secondary-hz" style={{ fontSize: 'var(--hz-text-sm)' }}>
                      Average Productivity
                    </span>
                    <span style={{ fontWeight: 700, fontSize: 'var(--hz-text-lg)' }}>
                      {(insights?.averageProductivityPercent ?? 0).toFixed(1)}%
                    </span>
                  </div>
                  <div className="d-flex justify-content-between align-items-center">
                    <span className="text-secondary-hz" style={{ fontSize: 'var(--hz-text-sm)' }}>
                      Employee-Days Analyzed
                    </span>
                    <span style={{ fontWeight: 700, fontSize: 'var(--hz-text-lg)' }}>{insights?.employeeDaysAnalyzed ?? 0}</span>
                  </div>
                </div>
              </Card>
            </div>
          </>
        )}
      </div>

      {/* Requirements #3/#4 - Activity Report / Productivity Summary table */}
      <Card title="Productivity Summary" subtitle="One row per employee, per device, per day" bodyClassName="p-0">
        <Table
          columns={columns}
          rows={rows || []}
          getRowKey={(r, i) => `${r.employeeId}-${r.deviceId}-${r.date}-${i}`}
          isLoading={rowsLoading}
          isError={rowsError}
          onRetry={refetchRows}
          emptyTitle="No activity found"
          emptyDescription="Try widening the date range or clearing a filter."
        />
      </Card>
    </div>
  );
}

function RankingList({ items, unit, emptyText }) {
  if (!items || items.length === 0) {
    return (
      <p className="text-secondary-hz py-3 mb-0" style={{ fontSize: 'var(--hz-text-sm)' }}>
        {emptyText}
      </p>
    );
  }
  return (
    <div className="d-flex flex-column">
      {items.map((item, i) => (
        <div
          key={item.employeeId}
          className="d-flex align-items-center justify-content-between py-2"
          style={{ borderBottom: i < items.length - 1 ? '1px solid var(--hz-border-light)' : 'none' }}
        >
          <div className="d-flex align-items-center gap-2">
            <span
              className="d-flex align-items-center justify-content-center"
              style={{
                width: 22,
                height: 22,
                borderRadius: '50%',
                background: 'var(--hz-neutral-100)',
                fontSize: 11,
                fontWeight: 700,
                color: 'var(--hz-text-secondary)',
              }}
            >
              {i + 1}
            </span>
            <div>
              <div style={{ fontSize: 'var(--hz-text-sm)', fontWeight: 500 }}>{item.employeeName}</div>
              <div style={{ fontSize: 11, color: 'var(--hz-text-muted)' }}>{item.departmentName || '—'}</div>
            </div>
          </div>
          <span style={{ fontWeight: 600, fontSize: 'var(--hz-text-sm)' }}>
            {item.value} {unit}
          </span>
        </div>
      ))}
    </div>
  );
}
